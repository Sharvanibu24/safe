"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Bell, MapPin, Shield, User, Settings, LogOut, AlertTriangle, Clock, ChevronRight } from "lucide-react"
import { useRouter } from "next/navigation"
import DashboardHeader from "@/components/dashboard-header"
import EmergencyContacts from "@/components/emergency-contacts"
import SOSButton from "@/components/sos-button"

export default function DashboardPage() {
  const router = useRouter()
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [locationError, setLocationError] = useState("")

  useEffect(() => {
    // Get current location when component mounts
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          })
        },
        (error) => {
          console.error("Error getting location:", error)
          setLocationError("Unable to access your location. Please enable location services.")
        },
      )
    } else {
      setLocationError("Geolocation is not supported by your browser.")
    }
  }, [])

  const handleLogout = () => {
    // In a real app, you would handle logout logic here
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardHeader onLogout={handleLogout} />

      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Main Content */}
          <div className="flex-1">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">Welcome, Jane</h1>
              <p className="text-gray-600">Stay safe with SafeGuard</p>
            </div>

            {/* SOS Button */}
            <div className="mb-8">
              <SOSButton />
            </div>

            {/* Tabs */}
            <Tabs defaultValue="safety" className="mb-8">
              <TabsList className="grid grid-cols-3 mb-6">
                <TabsTrigger value="safety">Safety Status</TabsTrigger>
                <TabsTrigger value="contacts">Emergency Contacts</TabsTrigger>
                <TabsTrigger value="resources">Resources</TabsTrigger>
              </TabsList>

              <TabsContent value="safety">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <MapPin className="h-5 w-5 mr-2 text-rose-500" />
                        Location Status
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {locationError ? (
                        <div className="text-amber-600 flex items-center">
                          <AlertTriangle className="h-4 w-4 mr-2" />
                          {locationError}
                        </div>
                      ) : currentLocation ? (
                        <div>
                          <p className="text-green-600 flex items-center mb-2">
                            <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                              Active
                            </Badge>
                            <span className="ml-2">Location tracking enabled</span>
                          </p>
                          <p className="text-sm text-gray-500">
                            Coordinates: {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}
                          </p>
                        </div>
                      ) : (
                        <p className="text-gray-500">Getting your location...</p>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <Bell className="h-5 w-5 mr-2 text-rose-500" />
                        Alert Status
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-2">No active alerts</p>
                      <p className="text-sm text-gray-500 flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        Last test: 2 days ago
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="contacts">
                <EmergencyContacts />
              </TabsContent>

              <TabsContent value="resources">
                <Card>
                  <CardHeader>
                    <CardTitle>Safety Resources</CardTitle>
                    <CardDescription>Access helpful safety information and local resources</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <ResourceItem
                        title="Safety Tips"
                        description="Learn essential safety practices for various situations"
                        link="/resources/safety-tips"
                      />
                      <ResourceItem
                        title="Local Support Services"
                        description="Find support services in your area"
                        link="/resources/local-services"
                      />
                      <ResourceItem
                        title="Emergency Numbers"
                        description="Important emergency contact numbers"
                        link="/resources/emergency-numbers"
                      />
                      <ResourceItem
                        title="Self-Defense Techniques"
                        description="Basic self-defense moves everyone should know"
                        link="/resources/self-defense"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="w-full md:w-80">
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Profile</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 mb-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src="/placeholder.svg?height=64&width=64" alt="Jane Doe" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">Jane Doe</p>
                    <p className="text-sm text-gray-500">jane.doe@example.com</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/profile">
                      <User className="mr-2 h-4 w-4" />
                      Edit Profile
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/settings">
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-rose-500 hover:text-rose-600 hover:bg-rose-50"
                    onClick={handleLogout}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    Log Out
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-rose-500" />
                  Safety Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-sm">
                  <div>
                    <h4 className="font-medium mb-1">Share your location</h4>
                    <p className="text-gray-600">
                      Always let someone know where you're going and when you expect to return.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Stay aware</h4>
                    <p className="text-gray-600">Be mindful of your surroundings, especially in unfamiliar areas.</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Trust your instincts</h4>
                    <p className="text-gray-600">
                      If something doesn't feel right, it probably isn't. Don't hesitate to leave or call for help.
                    </p>
                  </div>
                  <Button variant="link" className="p-0 h-auto text-rose-500" asChild>
                    <Link href="/resources/safety-tips">View all safety tips</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

function ResourceItem({
  title,
  description,
  link,
}: {
  title: string
  description: string
  link: string
}) {
  return (
    <Link href={link} className="block">
      <div className="flex items-center justify-between p-4 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
        <div>
          <h3 className="font-medium text-gray-900">{title}</h3>
          <p className="text-sm text-gray-600">{description}</p>
        </div>
        <ChevronRight className="h-5 w-5 text-gray-400" />
      </div>
    </Link>
  )
}
